#ifndef MENU_H
#define MENU_H

#include <iostream>
#include <limits>
#include "gestionarActividad.h"
#include "ListaDifusion.h"
#include "Certificado.h"
#include "Usuario.h"
using namespace std;

void mostrarMenuVisitante();
void mostrarMenuRegistrado();
void mostrarMenuAdmin();

#endif //
