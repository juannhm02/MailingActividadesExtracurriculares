#ifndef CERTIFICADO_H
#define CERTIFICADO_H

#include <string>

using namespace std;


#endif // CERTIFICADO_H
