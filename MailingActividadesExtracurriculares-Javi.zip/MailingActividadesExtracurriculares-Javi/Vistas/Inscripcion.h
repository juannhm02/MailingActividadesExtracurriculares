#ifndef INSCRIPCION_H
#define INSCRIPCION_H

#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <limits>

#include "Usuario.h"
#include "gestionarActividad.h"


using namespace std;




#endif // INSCRIPCION_H
