#include "Inscripcion.h"

using namespace std;






